a = { Buckets:
   [ { Name: 'ece1779a2', CreationDate: '1' },
     { Name: 'test1779', CreationDate: '2'} ],
  Owner: 
   { DisplayName: 'kaiyan.zhang',
     ID: '79076b8b4eba9f158d519d8399df2c004478d079fa8b8485d21f34cd6c89ae91' } };

console.log(a.Buckets[0].Name);